PricePulse files

1. PricePulse_Report_with_Screenshot.pdf – assignment report.
2. pricepulse_prototype.html – interactive sample prototype.

On Android: download the HTML file, open Files/My Files > Downloads, tap the file, then choose Chrome. If it does not appear, long-press the file and use Share/Open with > Chrome.
All prices are illustrative sample data, not live retailer prices. The PDF screenshot is a labelled preview, not proof of test execution.
